# Send SMS to Indian numbers from your own Python backend (free)

Uses the open-source app **SMS Gateway for Android** (capcom6/android-sms-gateway).
Your backend calls an HTTP API -> the app on your phone -> SMS goes out from your SIM.
Cost: only your normal SIM plan.

Docs: https://docs.sms-gate.app  |  Repo: https://github.com/capcom6/android-sms-gateway

## 1. Phone setup

1. Download the latest **secure (release)** APK from
   https://github.com/capcom6/android-sms-gateway/releases and install it
   (allow "install unknown apps" for your browser/file manager).
2. Open the app, grant **SEND_SMS** (and READ_PHONE_STATE if you want to choose a SIM).
3. Turn on the **Cloud Server** switch, then tap the button at the bottom until it shows **Online**.
4. Note the **username and password** shown in the Cloud Server section.
5. Android Settings -> Apps -> SMS Gateway -> Battery -> set to **Unrestricted / don't optimize**.
6. In the app, enable **send rate limiting** to avoid operator throttling.
7. Keep the phone on, with signal and internet.

## 2. Laptop setup

```bash
cd sms-gateway-starter
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env             # Windows: copy .env.example .env
# edit .env: paste SMSGATE_USER / SMSGATE_PASS from the app, set API_KEY
```

## 3. Test it

Check phone & gateway connection:
```bash
python check_status.py
```

Send a test SMS:
```bash
python send_test.py 9876543210 "Hello from my backend"
```

Use a friend's number or your second number. Numbers can be `9876543210`, `919876543210` or `+919876543210`.

## 4. Use inside your project

Simplest: import the function.

```python
from sms_client import send_sms
send_sms("9876543210", "Your OTP is 482913")
```

Or run the included FastAPI example:

```bash
uvicorn app:app --reload
curl -X POST http://127.0.0.1:8000/send-sms \
  -H "X-API-Key: YOUR_API_KEY" -H "Content-Type: application/json" \
  -d '{"number": "9876543210", "text": "Hello!"}'
```

## Good to know

- **Volume:** keep it low. Indian carriers cap SMS per SIM per day and may flag/block heavy senders. `DAILY_LIMIT` in `.env` is an in-memory counter (resets on restart).
- **Delivery:** some carriers filter OTP/promotional-looking texts from normal SIMs. Test on Jio, Airtel and Vi.
- **Security:** never commit `.env`. Keep `API_KEY` secret so nobody can send SMS from your number.
- **Local mode (optional):** in the app enable **Local Server**, set `SMSGATE_URL=http://<phone_ip>:8080/message`. Works only when laptop and phone share Wi-Fi (or use Tailscale). Username/password come from the app's Local Server section.
- **Troubleshooting:** 401 = wrong credentials; timeout = phone offline or app killed by battery optimization; message stuck = check status inside the app.
- **Going bigger later:** for real users/high volume, switch to a DLT-registered provider (Fast2SMS, MSG91).
