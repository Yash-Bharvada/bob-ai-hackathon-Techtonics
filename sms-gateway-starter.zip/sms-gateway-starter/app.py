"""Example FastAPI backend that sends SMS through your phone.

Run:  uvicorn app:app --reload
Test: curl -X POST http://127.0.0.1:8000/send-sms \
        -H "X-API-Key: <API_KEY from .env>" -H "Content-Type: application/json" \
        -d '{"number": "9876543210", "text": "Hello!"}'
"""
import os
import secrets

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from sms_client import SMSError, get_device_info, send_sms

API_KEY = os.getenv("API_KEY", "")
app = FastAPI(title="SMS via my phone")


@app.get("/")
def index():
    return {"status": "ok", "service": "SMS Gateway Backend"}


@app.get("/device-status")
def device_status(x_api_key: str = Header(default="")):
    if not API_KEY or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key")
    try:
        return get_device_info()
    except SMSError as e:
        raise HTTPException(status_code=400, detail=str(e))


class SMSRequest(BaseModel):
    number: str
    text: str = Field(min_length=1, max_length=480)


@app.post("/send-sms")
def send(req: SMSRequest, x_api_key: str = Header(default="")):
    # Protect the endpoint: otherwise anyone could send SMS from your SIM.
    if not API_KEY or not secrets.compare_digest(x_api_key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key")
    try:
        return send_sms(req.number, req.text)
    except SMSError as e:
        raise HTTPException(status_code=400, detail=str(e))

