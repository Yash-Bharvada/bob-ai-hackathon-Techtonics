"""Quick test:  python send_test.py 9876543210 "Hello from my backend"  """
import sys
from sms_client import send_sms

if len(sys.argv) < 3:
    sys.exit('Usage: python send_test.py <number> "<message>"')

print(send_sms(sys.argv[1], sys.argv[2]))
