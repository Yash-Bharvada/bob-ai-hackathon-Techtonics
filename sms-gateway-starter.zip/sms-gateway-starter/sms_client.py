"""Small client for SMS Gateway for Android (capcom6/android-sms-gateway).

Sends SMS through your own phone/SIM via the app's Cloud or Local server API.
"""
import os
import re
import threading
from datetime import date

import requests
from dotenv import load_dotenv

load_dotenv()

URL = os.getenv("SMSGATE_URL", "https://api.sms-gate.app/3rdparty/v1/message")
USER = os.getenv("SMSGATE_USER", "")
PASSWORD = os.getenv("SMSGATE_PASS", "")
DAILY_LIMIT = int(os.getenv("DAILY_LIMIT", "50"))

SIM_NUMBER = int(os.getenv("SMSGATE_SIM", "1")) if os.getenv("SMSGATE_SIM") else None

_lock = threading.Lock()
_counter = {"day": date.today(), "count": 0}


class SMSError(Exception):
    pass


def normalize_indian_number(number: str) -> str:
    """Return the number in +91XXXXXXXXXX form. Accepts 10 digits, 91..., +91..., 0..."""
    digits = re.sub(r"[^\d+]", "", number.strip())
    if digits.startswith("+"):
        return digits
    digits = digits.lstrip("0")
    if len(digits) == 10:
        return "+91" + digits
    if len(digits) == 12 and digits.startswith("91"):
        return "+" + digits
    raise SMSError(f"Invalid phone number: {number!r}")


def _check_and_count() -> None:
    with _lock:
        today = date.today()
        if _counter["day"] != today:
            _counter["day"], _counter["count"] = today, 0
        if _counter["count"] >= DAILY_LIMIT:
            raise SMSError(f"Daily limit of {DAILY_LIMIT} SMS reached")
        _counter["count"] += 1


def send_sms(number: str, text: str, sim_number: int | None = None) -> dict:
    if not USER or not PASSWORD:
        raise SMSError("Set SMSGATE_USER and SMSGATE_PASS in your .env file")
    to = normalize_indian_number(number)
    _check_and_count()
    payload = {"textMessage": {"text": text}, "phoneNumbers": [to]}
    effective_sim = sim_number if sim_number is not None else SIM_NUMBER
    if effective_sim is not None:
        payload["simNumber"] = effective_sim
    try:
        resp = requests.post(
            URL,
            auth=(USER, PASSWORD),
            json=payload,
            timeout=15,
        )
        resp.raise_for_status()
    except requests.RequestException as e:
        raise SMSError(f"Gateway request failed: {e}") from e
    return resp.json()


def get_device_info() -> list:
    if not USER or not PASSWORD:
        raise SMSError("Set SMSGATE_USER and SMSGATE_PASS in your .env file")
    device_url = URL.rsplit("/message", 1)[0] + "/device"
    try:
        resp = requests.get(device_url, auth=(USER, PASSWORD), timeout=15)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        raise SMSError(f"Gateway request failed: {e}") from e

