"""Check gateway and phone connection status: python check_status.py"""
from sms_client import get_device_info, SMSError

try:
    devices = get_device_info()
    print("Gateway Connected Successfully!")
    print(f"Total Paired Devices: {len(devices)}")
    for d in devices:
        print("-" * 40)
        print(f"Device ID: {d.get('id')}")
        print(f"Name:      {d.get('name')}")
        print(f"Last Seen: {d.get('lastSeen')}")
        sims = d.get('simCards', [])
        print(f"SIM Cards: {len(sims)}")
        for sim in sims:
            print(f"  - Slot {sim.get('slotIndex')}: {sim.get('carrierName')} ({sim.get('phoneNumber')})")
    print("-" * 40)
except SMSError as e:
    print(f"Error checking device status: {e}")
